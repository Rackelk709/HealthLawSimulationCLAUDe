# Redwood Valley – Public Health Crisis Simulation

A static, no-build web simulation: briefing → five decisions (with indicators, required legal/ethical reasoning, consequences) → debrief → downloadable record. Students submit the record through your LMS (e.g. Canvas). Nothing is sent to any server; work is stored only in the student's browser and in the file they download.

## Publish on GitHub Pages
1. Create a repository and upload everything in this folder (keep the folder structure; `.nojekyll` is included).
2. **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `/ (root)`**.
3. After a minute the site is at `https://<user>.github.io/<repo>/`. Link that from Canvas.

Test locally by double-clicking `index.html` (works offline) or running `python3 -m http.server`.

## How students submit
At the end they enter their name, then choose **Download PDF**, **Download text**, or **Copy text**, and upload/paste it into your Canvas assignment. The simulation cannot submit for them. To add a direct link button, set `config.submission.linkUrl` in `js/scenario.js`.

## Change the scenario
Edit only `js/scenario.js` (it is commented). Change `config.id` for a new scenario so old saved work is not reused, and bump `config.version` if you alter the number of decisions after students have started. If something is wrong the page lists the problems in plain language.

## Things to settle before classroom use
- **Accessibility:** built toward WCAG 2.1 AA (contrast, keyboard, focus, labels, 12px minimum text) and checked with axe-core, but automated tools catch only part of the issues; do a keyboard and screen-reader pass.
- **Hosting/ownership/SSO/data:** GitHub Pages is public and has no login. The scenario is fictional and no data leaves the browser, but confirm with SMU OIT whether a personal GitHub site is acceptable, who maintains it, and whether it overlaps Canvas.
- **Integrity:** the record is generated in the browser and can be edited by the student.
- On shared computers, students should choose **Start over** to clear saved work.

## Files
`index.html` · `css/styles.css` · `js/scenario.js` (content) · `js/engine.js` (rules) · `js/report.js` (PDF/text) · `js/app.js` (screens) · `js/vendor/` (pdf-lib, fontkit, fonts) · `THIRD_PARTY_NOTICES.md`
